# River Monitoring System

Assignment 3 for Embedded Systems and IoT of professor A. Ricci @ "Alma Mater Studiorum" - University of Bologna.

[![PlatformIO CI](https://github.com/aleemont1/esiot-23-24-assignment3/actions/workflows/platformio.yml/badge.svg)](https://github.com/aleemont1/esiot-23-24-assignment3/actions/workflows/platformio.yml)
[![Java CI with Gradle](https://github.com/aleemont1/esiot-23-24-assignment3/actions/workflows/gradle.yml/badge.svg?branch=main)](https://github.com/aleemont1/esiot-23-24-assignment3/actions/workflows/gradle.yml)
