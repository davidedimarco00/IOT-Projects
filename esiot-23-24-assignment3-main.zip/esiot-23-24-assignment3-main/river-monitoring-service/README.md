RIVER-MONITORING-SERVICE


this server as a broker it's the intermediary between all the system components.

Communicate with Arduino using Serial Line 
Communicate with esp32 using MQTT 
Communicate with frontend dashboard using HTTP 