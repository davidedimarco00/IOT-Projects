# Smart Bridge
[![PlatformIO CI](https://github.com/aleemont1/esiot-23-24-assignment2/actions/workflows/platformio.yml/badge.svg)](https://github.com/aleemont1/esiot-23-24-assignment2/actions/workflows/platformio.yml) 

Assignment 2 for Embedded Systems and IoT of professor A. Ricci @ "Alma Mater Studiorum" - University of Bologna.

