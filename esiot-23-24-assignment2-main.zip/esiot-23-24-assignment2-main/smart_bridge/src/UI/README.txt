This folder contains the UI interface in order to IO from/to Serial USB line.
It's written in python , so it's necessary to install python interpreter on local computer.


//THIS CLASS MUST BE DIVIDED INTO MODULE.