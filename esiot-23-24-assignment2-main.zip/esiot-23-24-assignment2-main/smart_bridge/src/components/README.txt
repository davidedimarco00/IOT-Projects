----This folders contains files for handling the behaviour of single components in the project.
Structure:
|_ api
   |_ All interfaces here
|_ impl
   |_ All implementations here


--------- This folders contains .cpp and .h files.
--------- Each .cpp is the implementation of .h file